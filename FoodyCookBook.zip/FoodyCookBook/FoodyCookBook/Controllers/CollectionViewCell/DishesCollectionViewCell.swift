//
//  DishesCollectionViewCell.swift
//  FoodyCookBook
//
//  Created by Arun Darla on 14/04/21.
//

import UIKit

class DishesCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var dishImage: ImageCacheView!
    @IBOutlet weak var lblDishName: UILabel!
    
}
