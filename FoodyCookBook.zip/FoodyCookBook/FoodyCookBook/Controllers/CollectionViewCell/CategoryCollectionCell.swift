//
//  CategoryCollectionCell.swift
//  FoodyCookBook
//
//  Created by Arun Darla on 14/04/21.
//

import UIKit

class CategoryCollectionCell: UICollectionViewCell {
    
    @IBOutlet weak var categoryImage: ImageCacheView!
    @IBOutlet weak var lblCategory: UILabel!
    
    
    
    
    
    
}
