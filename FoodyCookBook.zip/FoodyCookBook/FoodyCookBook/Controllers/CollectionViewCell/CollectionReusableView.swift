//
//  CollectionReusableView.swift
//  FoodyCookBook
//
//  Created by Arun Darla on 14/04/21.
//

import UIKit

class CollectionReusableView: UICollectionReusableView {
    
    @IBOutlet weak var secetionLbl: UILabel!
        
}
